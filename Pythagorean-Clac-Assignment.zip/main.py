# Pyhton Pythagorean Calculator Assignment
import math
# Input
a = float(input("Number of side one: "))
b = float(input("Number of side two: "))

# Process
c = a ** 2 + b ** 2
total = math.sqrt(c)

# Output
print("Number of side three is: " + str(round(total, 2)) + "!")